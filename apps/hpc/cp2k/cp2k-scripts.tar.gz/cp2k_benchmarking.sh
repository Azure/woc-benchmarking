#!/bin/bash

export NODE_LIST=(16 8 4 2 1)
export PPN_LIST=(120 96 64)
export THRD_LIST=(1)
export compiler=gcc-9.2.0
export mpi_library=hpcx-v2.8.3
export BENCHMARK="H2O-DFT-LS"
export REPS=3

export SKU_TYPE=hbv3

export AZURE_STORAGE_CONNECTION_STRING=" "
export CP2K_SPEC="cp2k@8.1"
export INPUTDIR=/share/home/hpcuser/amirreza/cp2k/input
#################################################################################################################
basedir=$(pwd)
VMINFO=$(sudo curl -s -H Metadata:true "http://169.254.169.254/metadata/instance/compute?api-version=2018-10-01")
export clustertype=$(echo $VMINFO |sed -e 's/"//g' |sed -e 's/^.*vmSize://g' |cut -d"," -f1 |cut -d"_" -f2)

yes | sudo yum install python3
module load $compiler
module load mpi/$mpi_library
SHARED_APP=${SHARED_APP:-/apps}
module use ${SHARED_APP}/modulefiles
module load spack/spack
source $SPACK_SETUP_ENV
export SPACK_VERSION=$(spack -V)
. /apps/spack/$SPACK_VERSION/spack/share/spack/setup-env.sh
spack load $CP2K_SPEC

CP2K_PATH=$(command -v cp2k.psmp)
echo "cp2k path:" $CP2K_PATH
echo "mpi library: $(command -v mpirun)"

JOBID=INITIALIZE

LOGFILE=log_${clustertype}_${BENCHMARK}_bench_${compiler}_${mpi_library}.txt
# File to keep a record of the jobids of the benchmarking runs
touch ${LOGFILE}

OUTPUTDIR=${basedir}/run_${clustertype}/${compiler}/${mpi_library}/$BENCHMARK/
mkdir -p $OUTPUTDIR
cp $INPUTDIR/cp2k-H2O-DFT-LS-initial-files.tar.gz $OUTPUTDIR
cd $OUTPUTDIR

for NNODES in ${NODE_LIST[@]}; do
for NPPNS in ${PPN_LIST[@]}; do
for NTHRDS in ${THRD_LIST[@]}; do

NTASKS=$((NNODES * NPPNS))
NCPUS=$((NPPNS * NTHRDS))

cat <<EOF > ${BENCHMARK}_benchmark_${NNODES}_${NPPNS}_${NTHRDS}.pbs	
#!/bin/bash
#PBS -N cp2k-${BENCHMARK}-${NNODES}_${NPPNS}_${NTHRDS}
#PBS -l walltime=01:00:00
#PBS -l select=$NNODES:ncpus=$NCPUS:mpiprocs=$NPPNS:ompthreads=$NTHRDS
#PBS -l place=scatter:exclhost
#PBS -j oe

ulimit -s unlimited
ulimit -l unlimited
ulimit -a

module load $compiler
module load mpi/$mpi_library
module list

yes | sudo yum install python3
. /apps/spack/$SPACK_VERSION/spack/share/spack/setup-env.sh
spack load $CP2K_SPEC

CP2K_PATH=\$(command -v cp2k.psmp)
echo "cp2k path:" \$CP2K_PATH
echo "mpi library: \$(command -v mpirun)"

key0=\$(cat /sys/class/infiniband/mlx5_ib0/ports/1/pkeys/0)
key1=\$(cat /sys/class/infiniband/mlx5_ib0/ports/1/pkeys/1)
    if [ \$((\$key0 - \$key1)) -gt 0 ]; then
        export IB_PKEY=\$key0
    else
        export IB_PKEY=\$key1
    fi
export UCX_IB_PKEY=\$(printf '0x%04x' "\$(( \$IB_PKEY & 0x0FFF ))")
echo UCX_IB_PKEY is \$UCX_IB_PKEY

cd \$PBS_O_WORKDIR
BOUTPUTDIR=CP2KH2O_${NNODES}_${NPPNS}_${NTHRDS}.\${PBS_JOBID}
mkdir \$BOUTPUTDIR
cd \$BOUTPUTDIR

export FLG=1

if [ "$NPPNS" == "120" ]
then
            mppflags="--bind-to cpulist:ordered --cpu-set 0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119 --report-bindings "
elif [ "$NPPNS" == "96" ]
then
            mppflags="--bind-to cpulist:ordered --cpu-set 0,1,2,3,4,5,8,9,10,11,12,13,16,17,18,19,20,21,24,25,26,27,28,29,30,31,32,33,34,35,38,39,40,41,42,43,46,47,48,49,50,51,54,55,56,57,58,59,60,61,62,63,64,65,68,69,70,71,72,75,76,77,78,79,80,81,84,85,86,87,88,89,90,91,92,93,94,95,98,99,100,101,102,103,106,107,108,109,110,111,114,115,116,117,118,119 --report-bindings "
elif [ "$NPPNS" == "64" ]
then
            mppflags="--bind-to cpulist:ordered --cpu-set 0,1,2,3,8,9,10,11,16,17,18,19,24,25,26,27,30,31,32,33,38,39,40,41,46,47,48,49,54,55,56,57,60,61,62,63,68,69,70,71,76,77,78,79,84,85,86,87,90,91,92,93,98,99,100,101,106,107,108,109,114,115,116,117 --report-bindings"
elif [ "$NPPNS" == "32" ]
then
            mppflags="--bind-to cpulist:ordered --cpu-set 0,1,8,9,16,17,24,25,30,31,38,39,46,47,54,55,60,61,68,69,76,77,84,85,90,91,98,99,106,107,114,115 --report-bindings"
elif [ "$NPPNS" == "16" ]
then
            mppflags="--bind-to cpulist:ordered --cpu-set 0,8,16,24,30,38,46,54,60,68,76,84,90,98,106,114 --report-bindings"
else
            echo "No defined setting for Core count: $NPPNS"
            mppflags="--report-bindings"
            FLG=0
fi

NNUMA=\$(lscpu | grep "NUMA node(s):" | awk -F ' ' '{print \$3}')
PPS=\$(($NPPNS / NNUMA))
if [ \$((PPS * NNUMA - $NPPNS)) -eq 0 ]; then
        NUMA_OPT="ppr:\$PPS:numa:pe=${NTHRDS}"
else
    NSC=\$(lscpu | grep "Socket(s):" | awk -F ' ' '{print \$2}')
    PPS=\$(($NPPNS / NSC))
    if [ \$((PPS * NSC - $NPPNS)) -eq 0 ]; then
	    NUMA_OPT="ppr:\$PPS:socket:pe=${NTHRDS}"
    else
        NUMA_OPT="socket:pe=${NTHRDS}"
    fi
fi

echo NUMA_OPT: \$NUMA_OPT

cat \$PBS_NODEFILE | sort -u > hostlist

if [ \${OMP_NUM_THREADS} -eq 1 -a "${SKU_TYPE}" == "hbv3" -a \${FLG} -eq 1 ]; then
    export mpi_options="-machinefile \$PBS_NODEFILE -np $NTASKS \$mppflags --rank-by slot 
    --mca btl self --mca pml ucx -x OMP_NUM_THREADS=$NTHRDS -x OMP_PLACES=cores -x OMP_PROC_BIND=close 
    -x UCX_NET_DEVICES=mlx5_ib0:1 -x UCX_IB_PKEY  -x UCX_TLS=dc,sm,self -x UCX_IB_SL=1
    -x UCX_DC_MLX5_NUM_DCI=15 -x UCX_UNIFIED_MODE=y 
    -x UCX_IB_ADDR_TYPE=ib_global -x UCX_DC_MLX5_TM_ENABLE=y -x UCX_MAX_EAGER_RAILS=3 
    -x UCX_MAX_RNDV_RAILS=3 -x LD_LIBRARY_PATH -x PATH -x PWD -x MPI_BUFFER_SIZE --display-map" 
else
    export mpi_options="-machinefile \$PBS_NODEFILE -np $NTASKS --bind-to core --map-by \$NUMA_OPT --rank-by slot 
    --mca btl self --mca pml ucx -x OMP_NUM_THREADS=$NTHRDS -x OMP_PLACES=cores -x OMP_PROC_BIND=close 
    -x UCX_NET_DEVICES=mlx5_ib0:1 -x UCX_IB_PKEY -x UCX_TLS=dc,sm,self -x UCX_IB_SL=1
    -x UCX_DC_MLX5_NUM_DCI=15 -x UCX_UNIFIED_MODE=y 
    -x UCX_IB_ADDR_TYPE=ib_global -x UCX_DC_MLX5_TM_ENABLE=y -x UCX_MAX_EAGER_RAILS=3 
    -x UCX_MAX_RNDV_RAILS=3 -x LD_LIBRARY_PATH -x PATH -x PWD -x MPI_BUFFER_SIZE --display-map" 
fi

echo mpi_options: \$mpi_options

export OMP_NUM_THREADS=$NTHRDS

cp ../cp2k-H2O-DFT-LS-initial-files.tar.gz .
tar -xzvf cp2k-H2O-DFT-LS-initial-files.tar.gz

mpirun \$mpi_options $CP2K_PATH -i H2O-dft-ls.NREP4.inp -o outputfile.log

#to find the wall time
grep "CP2K    " outputfile.log | awk -F ' ' '{print \$6}' > exec_time.log

exit 0

EOF

for ((i=1 ; i<= $REPS ; i++)); do
## Submit job
#if test "${JOBID}" = "INITIALIZE"; then
  JOBID=$(qsub ${BENCHMARK}_benchmark_${NNODES}_${NPPNS}_${NTHRDS}.pbs)
#else
#  JOBID=$(qsub -W depend=afterany:$JOBID lihfx_benchmark_${NNODES}_${NPPNS}_${NTHRDS}.pbs)
#fi
echo "CP2K Benchmarking: $BENCHMARK, tasks ${NTASKS} nodes ${NNODES} ppn ${NPPNS}, threads $NTHRDS, PBS job id ${JOBID}" >> ${basedir}/${LOGFILE}
done

done
done
done

cd ${basedir}

